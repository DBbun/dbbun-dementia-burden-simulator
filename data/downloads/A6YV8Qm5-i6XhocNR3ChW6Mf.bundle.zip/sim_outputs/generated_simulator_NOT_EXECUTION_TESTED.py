#!/usr/bin/env python3
"""
Dementia Caregiver Medication-Process Burden (German Survey, n=180)
Reference implementation of the interactive spec. Standard library only.
"""

DEFAULT_INPUTS = {
    "communicating_burden_pct": 27.3,
    "accompanying_burden_pct": 20.0,
    "reminding_burden_pct": 18.3,
    "obtaining_burden_pct": 4.4,
    "organizing_burden_pct": 5.7,
    "zarit_score": 14.6,
    "nurse_support_pct": 37.8,
    "fast_service_importance_pct": 73.5,
}

SCENARIOS = {
    "full_nurse_support_coverage": {"nurse_support_pct": 100},
    "no_nurse_support_coverage": {"nurse_support_pct": 0},
}


def compute_outputs(inputs):
    communicating = inputs["communicating_burden_pct"]
    accompanying = inputs["accompanying_burden_pct"]
    reminding = inputs["reminding_burden_pct"]
    obtaining = inputs["obtaining_burden_pct"]
    organizing = inputs["organizing_burden_pct"]
    zarit_score = inputs["zarit_score"]
    nurse_support_pct = inputs["nurse_support_pct"]

    patient_facing_burden_avg = (communicating + accompanying + reminding) / 3
    logistical_burden_avg = (obtaining + organizing) / 2
    burden_gap = patient_facing_burden_avg - logistical_burden_avg
    general_caregiver_burden_score = zarit_score
    nurse_support_coverage_pct = nurse_support_pct

    return {
        "patient_facing_burden_avg": patient_facing_burden_avg,
        "logistical_burden_avg": logistical_burden_avg,
        "burden_gap": burden_gap,
        "general_caregiver_burden_score": general_caregiver_burden_score,
        "nurse_support_coverage_pct": nurse_support_coverage_pct,
    }


def run_scenario(scenario_overrides, base_inputs=None):
    inputs = dict(DEFAULT_INPUTS if base_inputs is None else base_inputs)
    inputs.update(scenario_overrides)
    return inputs, compute_outputs(inputs)


def print_outputs(title, inputs, outputs):
    print(f"--- {title} ---")
    print("Inputs:")
    for k, v in inputs.items():
        print(f"  {k}: {v}")
    print("Outputs:")
    print(f"  patient_facing_burden_avg (%%): {outputs['patient_facing_burden_avg']:.4f}")
    print(f"  logistical_burden_avg (%%): {outputs['logistical_burden_avg']:.4f}")
    print(f"  burden_gap (pp): {outputs['burden_gap']:.4f}")
    print(f"  general_caregiver_burden_score: {outputs['general_caregiver_burden_score']:.4f}")
    print(f"  nurse_support_coverage_pct (%%): {outputs['nurse_support_coverage_pct']:.4f}")
    print()


if __name__ == "__main__":
    base_inputs = dict(DEFAULT_INPUTS)
    base_outputs = compute_outputs(base_inputs)
    print_outputs("Default inputs", base_inputs, base_outputs)

    for scenario_id, overrides in SCENARIOS.items():
        scenario_inputs, scenario_outputs = run_scenario(overrides, base_inputs=DEFAULT_INPUTS)
        print_outputs(scenario_id, scenario_inputs, scenario_outputs)