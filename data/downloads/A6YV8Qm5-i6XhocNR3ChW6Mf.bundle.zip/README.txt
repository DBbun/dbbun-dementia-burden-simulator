================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : A6YV8Qm5-i6XhocNR3ChW6Mf
    Generated   : 2026-11-09 13:20:31 UTC
================================================================

TITLE
-----
Dementia Caregiver Medication-Process Burden (German Survey, n=180)

BOUNDARY
--------
This simulation reflects a German nationwide cross-sectional survey of 180 informal caregivers of people with dementia, examining self-reported burden from medication-related tasks ('medication process' burden) and a validated general caregiver burden score (Zarit Burden Interview, short form). It covers only self-reported percentages and scale scores from this single survey wave; it does not include any dollar costs, caregiving hours, income loss, or federal/national data, and findings should not be generalized beyond caregivers recruited through German dementia self-help groups.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a German nationwide survey of 180 informal caregivers of people with dementia examining the burden caregivers feel from managing medications ('medication process' or MP-related burden), alongside the validated Zarit Burden Interview for general caregiver burden. It finds that patient-facing tasks (explaining medication information, accompanying to appointments, reminding about doses) were rated as more burdensome than logistical tasks (collecting prescriptions, preparing doses). Support from community nurses did not measurably reduce either general or MP-related burden, and caregivers valued fast service and thorough counselling from community pharmacies more than organisational services like delivery or app-based ordering. The study reports no dollar costs, time-use, or income-loss figures; its findings are limited to self-reported burden percentages and a validated burden-interview score from a convenience sample recruited through dementia caregiver self-help groups.

WHY THIS COULD BE USEFUL
------------------------
This document's findings could inform dementia care delivery teams, community pharmacies, and nursing services in Germany (and similar health systems) about which specific medication-process tasks drive caregiver burden, and about where current community-nurse support does and does not help. It does not support any cost or payer-facing simulation, since no dollar amounts, time-use, or income-loss figures are reported. Patient/caregiver advocates could use the item-level burden breakdown to argue for communication-focused pharmacy and clinical interventions rather than purely logistical support services.

WHAT YOU COULD DO WITH IT
-------------------------
- A community pharmacy or dementia caregiver support organization could use the item-level burden percentages (27.3% for communicating medication information vs. 4.4% for obtaining medications) to prioritize counselling-based services over logistics-only services like delivery.
- A care delivery team designing or evaluating community-nurse support programs could use the finding that nurse support did not significantly reduce MP-related burden (U=2896.0, p=0.595) or general caregiver burden (U=3837.5, p=0.066, described by the authors as narrowly missing significance) to target future interventions at communication and decision-support tasks rather than purely practical tasks.

DETECTED FOCUS
--------------
dementia: Labeled reuse demonstration chosen by Dr. Kartoun; no federal evidence pack was curated for this condition.

SOURCE FILES
------------
PMC13063673.txt

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (8)
--------------
- Caregivers rating 'explaining medication info to patient' as (very) high burden (%), default 27.3, source: Document, Results section 'Components of the MP and their contribution to burden'; 0-100% range is an assumed exploration bound covering the full possible share, not from the source.
- Caregivers rating 'accompanying patient to appointments' as (very) high burden (%), default 20.0, source: Document, Results section 'Components of the MP and their contribution to burden'; 0-100% range is an assumed exploration bound, not from the source.
- Caregivers rating 'reminding patient to take medication' as (very) high burden (%), default 18.3, source: Document, Results section 'Components of the MP and their contribution to burden'; 0-100% range is an assumed exploration bound, not from the source.
- Caregivers rating 'obtaining medications from pharmacy' as (very) high burden (%), default 4.4, source: Document, Results section 'Components of the MP and their contribution to burden'; 0-100% range is an assumed exploration bound, not from the source.
- Caregivers rating 'organising/preparing medication doses' as (very) high burden (%), default 5.7, source: Document, Results section 'Components of the MP and their contribution to burden'; 0-100% range is an assumed exploration bound, not from the source.
- General caregiver burden score (Zarit Burden Interview, short form) (mean score), default 14.6, source: Document, Table 1 (mean 14.6, SD 5.1); the 0-48 range is an assumed exploration bound reflecting a commonly scored range for this instrument type, not a range stated in this document.
- Caregivers receiving community-nurse support with medication process (%), default 37.8, source: Document, Results section 'Influence of community nurses on burden'; 0-100% range is an assumed exploration bound, not from the source.
- Caregivers rating fast pharmacy service as (very) important (%), default 73.5, source: Document, Results section 'Informal caregivers' ratings of the importance of community pharmacy services'; 0-100% range is an assumed exploration bound, not from the source.

OUTPUTS (5)
-----------
- Average share rating patient-facing medication tasks as (very) high burden: 21.87 (%) at default assumptions
- Average share rating logistical medication tasks as (very) high burden: 5.05 (%) at default assumptions
- Patient-facing minus logistical burden average (percentage points; positive = patient-facing tasks rated more burdensome, negative = logistical tasks rated more burdensome): 16.82 (percentage points) at default assumptions
- General caregiver burden (Zarit Burden Interview, short form): 14.6 (mean score) at default assumptions
- Current community-nurse support coverage: 37.8 (%) at default assumptions

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.