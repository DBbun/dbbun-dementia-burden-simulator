================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : Ed67lNK3RNpXwl2P8TnT1B-l
    Generated   : 2026-11-09 13:20:34 UTC
================================================================

TITLE
-----
Dementia Caregiver Burden Simulator (Qatar Private Nursing Services, Zarit Burden Interview)

BOUNDARY
--------
This simulation represents a single cross-sectional survey of 101 caregivers (69.1% of 146 approached) of dementia patients under Qatar's Private Nursing Services (PNS) program at Hamad Medical Corporation, measured with the 22-item Zarit Burden Interview (ZBI, scored 0-88, higher = more burden). It covers overall burden prevalence and the two subgroup associations the study found statistically significant: spousal relationship to the patient (p=0.011) and lower caregiver education (p=0.019). The document also reports that gender (75.2% of caregivers were female) and caregiving hours per day were NOT significantly associated with burden category in this sample (p=0.53 and p=0.32 respectively) - these non-significant findings are kept visible rather than implied away. This simulation does NOT represent any dollar cost, income loss, diagnostic delay, or access-barrier data, because the source document reports none of these; it is a psychometric burden score study, not a cost-of-illness study, and its findings come from one program in one country and should not be generalized nationally or pooled with other countries' studies.

ABOUT THE SOURCE DOCUMENT
-------------------------
This is a cross-sectional survey study of 101 caregivers (out of 146 approached) of dementia patients cared for under Qatar's Private Nursing Services program at Hamad Medical Corporation. Using the 22-item Zarit Burden Interview (ZBI), it measures the physical, emotional, social, and financial burden these caregivers report, finding an average burden score of 42.8 (SD 19.6) on a 0-88 scale, with 36.6% experiencing moderate-to-severe burden and 18.8% severe burden. Burden was statistically associated with lower education and spousal relationship to the patient, while gender, age, nationality, living arrangement, and caregiving hours per day did not show a statistically significant association in this sample. The study reports no dollar costs, no direct medical expenditure data, and no data on diagnostic delay or insurance/access barriers; its burden measure is a composite psychometric score, not a monetary figure.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help dementia-program administrators and policymakers in Qatar (e.g., Hamad Medical Corporation's Private Nursing Services, the Ministry of Public Health, or planners of the National Dementia Plan) understand which caregiver subgroups report the highest ZBI-measured burden and target support resources accordingly. Because the document reports a psychometric burden score and subgroup associations rather than dollar costs, the simulator's usefulness is limited to burden-severity and service-targeting questions, not cost-of-illness estimation. It cannot answer questions about direct medical costs, lost income, or long-term financial consequences, since the document does not quantify these.

WHAT YOU COULD DO WITH IT
-------------------------
- Program administrators at Qatar's Private Nursing Services could use the ZBI subgroup findings (spousal caregivers at 37% severe burden, lower-education caregivers at higher moderate-to-severe burden) to prioritize which caregiver groups are offered respite care or counseling referrals first.
- Policy planners revising Qatar's National Dementia Plan could use the reported overall burden prevalence (36.6% moderate-to-severe, 18.8% severe among 101 surveyed caregivers) to gauge the scale of caregiver support services potentially needed, while recognizing this reflects a psychometric burden score and a single-program sample, not a cost or national prevalence estimate.

DETECTED FOCUS
--------------
dementia: Labeled reuse demonstration chosen by Dr. Kartoun; no federal evidence pack was curated for this condition.

SOURCE FILES
------------
PMC13612328.txt

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (6)
--------------
- Mean Zarit Burden Interview score (score (0-88 scale)), default 42.8, source: Document Abstract/Results/Table 2 reports a mean ZBI score of 42.8 (SD 19.6); the 0-88 min/max reflects the document's own description of the full ZBI scale range, not a chosen exploration bound.
- Moderate-to-severe burden prevalence (percent of caregivers), default 36.6, source: Document Abstract states 36.6% of caregivers experienced moderate-to-severe burden; the 0-100 range is an assumed exploration bound (the natural range for a percentage), not document-specified.
- Severe burden prevalence (percent of caregivers), default 18.8, source: Document Abstract/Results/Table 2 states 18.8% faced severe caregiving challenges; the 0-100 range is an assumed exploration bound, not document-specified.
- Severe burden prevalence among spousal caregivers (percent of spousal caregivers), default 37, source: Document Discussion/Table 3 reports 37% of spousal caregivers (a subgroup of n=13 within the 101 surveyed) reported severe burden, associated with relationship-to-patient (p=0.011); the 0-100 range is an assumed exploration bound.
- Minimal burden prevalence, graduate-or-above education (percent of graduate-educated caregivers), default 73, source: Document Results/Table 3 reports 73% of caregivers with graduate or higher education experienced minimal burden, associated with education level (p=0.019); the 0-100 range is an assumed exploration bound.
- Minimal burden prevalence, secondary education (percent of secondary-educated caregivers), default 26, source: Document Results/Table 3 reports 26% of secondary-educated caregivers experienced minimal burden, associated with education level (p=0.019); the 0-100 range is an assumed exploration bound.

OUTPUTS (5)
-----------
- Mean caregiver burden score: 42.8 (score (0-88 scale)) at default assumptions
- Moderate-to-severe burden prevalence: 36.6 (percent) at default assumptions
- Severe burden prevalence: 18.8 (percent) at default assumptions
- Spousal-minus-overall severe burden gap (positive = spousal caregivers more often severe; negative = less often): 18.2 (percentage points) at default assumptions
- Graduate-minus-secondary minimal burden gap (positive = graduate-educated caregivers more often minimal burden; negative = less often): 47 (percentage points) at default assumptions

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.