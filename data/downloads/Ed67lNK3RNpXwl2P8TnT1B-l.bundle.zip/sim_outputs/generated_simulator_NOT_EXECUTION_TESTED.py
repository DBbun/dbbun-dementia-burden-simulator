#!/usr/bin/env python3
"""
Dementia Caregiver Burden Simulator
(Qatar Private Nursing Services, Zarit Burden Interview)

Standard-library-only reference implementation of the interactive spec.
This reproduces the arithmetic defined in the spec's inputs/outputs for
the default inputs. It is a plain reference implementation, not a
reproduction of the source paper's full statistical model.

Boundary note: represents a single cross-sectional survey of 101
caregivers (69.1% of 146 approached) under Qatar's PNS program,
measured with the 22-item Zarit Burden Interview (ZBI, 0-88). No
cost, income-loss, diagnostic-delay, or access-barrier data are
represented.
"""

# ---------------------------------------------------------------------
# Default inputs (from spec "inputs")
# ---------------------------------------------------------------------

DEFAULT_INPUTS = {
    "mean_zbi_score": 42.8,
    "moderate_severe_burden_share": 36.6,
    "severe_burden_share": 18.8,
    "spousal_severe_burden_share": 37,
    "graduate_minimal_burden_share": 73,
    "secondary_minimal_burden_share": 26,
}


def compute_outputs(inputs):
    """Compute all output expressions exactly as specified."""

    mean_zbi_score = inputs["mean_zbi_score"]
    moderate_severe_burden_share = inputs["moderate_severe_burden_share"]
    severe_burden_share = inputs["severe_burden_share"]
    spousal_severe_burden_share = inputs["spousal_severe_burden_share"]
    graduate_minimal_burden_share = inputs["graduate_minimal_burden_share"]
    secondary_minimal_burden_share = inputs["secondary_minimal_burden_share"]

    # mean_zbi_burden_score_result = mean_zbi_score + 0
    mean_zbi_burden_score_result = mean_zbi_score + 0

    # moderate_severe_burden_prevalence_result = moderate_severe_burden_share + 0
    moderate_severe_burden_prevalence_result = moderate_severe_burden_share + 0

    # severe_burden_prevalence_result = severe_burden_share + 0
    severe_burden_prevalence_result = severe_burden_share + 0

    # spousal_severe_burden_gap = spousal_severe_burden_share - severe_burden_share
    spousal_severe_burden_gap = spousal_severe_burden_share - severe_burden_share

    # education_minimal_burden_gap = graduate_minimal_burden_share - secondary_minimal_burden_share
    education_minimal_burden_gap = (
        graduate_minimal_burden_share - secondary_minimal_burden_share
    )

    return {
        "mean_zbi_burden_score_result": mean_zbi_burden_score_result,
        "moderate_severe_burden_prevalence_result": moderate_severe_burden_prevalence_result,
        "severe_burden_prevalence_result": severe_burden_prevalence_result,
        "spousal_severe_burden_gap": spousal_severe_burden_gap,
        "education_minimal_burden_gap": education_minimal_burden_gap,
    }


OUTPUT_META = {
    "mean_zbi_burden_score_result": ("Mean caregiver burden score", "score (0-88 scale)"),
    "moderate_severe_burden_prevalence_result": ("Moderate-to-severe burden prevalence", "percent"),
    "severe_burden_prevalence_result": ("Severe burden prevalence", "percent"),
    "spousal_severe_burden_gap": ("Spousal-minus-overall severe burden gap", "percentage points"),
    "education_minimal_burden_gap": ("Graduate-minus-secondary minimal burden gap", "percentage points"),
}


if __name__ == "__main__":
    inputs = dict(DEFAULT_INPUTS)
    results = compute_outputs(inputs)

    print("Dementia Caregiver Burden Simulator (Qatar PNS, ZBI)")
    print("Default inputs:")
    for k, v in inputs.items():
        print(f"  {k} = {v}")

    print("\nOutputs:")
    for key, (label, unit) in OUTPUT_META.items():
        value = results[key]
        print(f"  {label}: {value} {unit}")