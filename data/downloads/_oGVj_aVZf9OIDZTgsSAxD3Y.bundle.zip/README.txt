================================================================
    DBbun Invisible Illness Burden Simulator - Local Interactive Bundle
    ============================================================
    Run ID      : _oGVj_aVZf9OIDZTgsSAxD3Y
    Generated   : 2026-11-08 16:28:45 UTC
================================================================

TITLE
-----
Dementia Caregiver Burden, Hours, and Depressive Symptoms (Puerto Rico, PREHCO Wave 3)

BOUNDARY
--------
This simulator models caregiving-hour intensity and the statistical association between caregiver burden and caregiver depressive symptoms reported in a single cross-sectional study of 101 dementia caregivers in Puerto Rico (PREHCO Wave 3, 2021-2022). It contains no dollar-denominated cost, income-loss, insurance, or access-barrier data because the source document reports none of these. Outputs are either direct transformations of the document's own reported means, standard deviations, and correlation statistic, or an illustrative benchmark comparison; none should be read as a cost estimate, a causal effect, or as generalizable beyond this specific sample.

ABOUT THE SOURCE DOCUMENT
-------------------------
This study used data from the Puerto Rican Elder: Health Conditions (PREHCO) Wave 3 survey to examine 101 informal caregivers of community-dwelling older adults with dementia in Puerto Rico. It measured caregiver depressive symptoms (Geriatric Depression Scale), caregiver burden (Zarit Burden Interview, 6-item version), behavioral and psychological symptoms of dementia in the care recipient (Neuropsychiatric Inventory Questionnaire), and caregivers' perceived social support (Lubben Social Network Scale). It found that caregiver burden and two derived BPSD symptom factors were each positively associated with caregiver depressive symptoms, that perceptual disturbances/apathy (driven mainly by appetite/eating symptoms) significantly strengthened the burden-depression link, and that perceived social support did not reduce this association. The study reports caregiving-hour intensity (average near 100 hours/week, with half the sample providing more than 100 hours/week) but contains no dollar-denominated cost data, no measure of lost income or employment impact, and no data on medical costs, insurance, or access barriers.

WHY THIS COULD BE USEFUL
------------------------
A simulator built from this document could help caregiving-support organizations, clinicians serving Puerto Rican/Hispanic dementia families, and researchers understand which specific dementia symptom patterns (particularly perceptual disturbances/apathy and appetite/eating problems) are most strongly tied to caregiver depressive symptoms, and how caregiving-hour intensity concentrates at very high levels (over 100 hr/week for half the sample). It would support questions about where to target symptom-focused or respite interventions, but it cannot answer questions about dollar costs, insurance, lost income, or long-term financial consequences because the document reports none of these. The findings are specific to a cross-sectional, proxy-reported Puerto Rican sample and should not be generalized to other populations without caveats.

WHAT YOU COULD DO WITH IT
-------------------------
- Caregiver-support program planners could use the reported BPSD-burden-depression associations (e.g., the stronger role of perceptual disturbances/apathy and appetite/eating symptoms) to prioritize symptom-specific caregiver training or respite resources, labeled as applicable to this Puerto Rican sample only.
- Researchers or policy analysts could use the reported caregiving-hour distribution (19.8% <35 hr/week, 29.7% 35-100 hr/week, 50.5% >100 hr/week) to illustrate the scale of unpaid time burden in this population when advocating for expanded formal/community-based dementia care services, while noting no dollar cost estimate is available from this document.

DETECTED FOCUS
--------------
dementia: Labeled reuse demonstration chosen by Dr. Kartoun; no federal evidence pack was curated for this condition.

SOURCE FILES
------------
PMC13017666.txt

AI MODEL
--------
Analysis, simulator specification and documentation text were written by: claude-sonnet-5

PARAMETERS (5)
--------------
- Weekly caregiving hours (hours/week), default 99.4, source: Results section and Table 1 (reported mean 99.4 hr/week, SD 60.1); 50-160 range is an assumed exploration bound based on roughly one standard deviation around the mean, not stated in the source.
- Standard full-time workweek (benchmark) (hours/week), default 40, source: Assumed external benchmark representing a standard full-time workweek; not from the source document. 30-40 range is an assumed exploration bound, not from the source.
- Caregiver burden score (ZBI-6) (score (0-24 scale)), default 7.9, source: Table 1 (6-item Zarit Burden Interview, mean 7.9, SD 6.3, instrument range 0-24).
- Concurrent BPSD symptom count (NPI-Q) (count (0-12 scale)), default 4.9, source: Table 1 (Neuropsychiatric Inventory Questionnaire, mean 4.9, SD 3.1, instrument range 0-12).
- Burden-depression correlation (r) (correlation coefficient), default 0.72, source: Results section (reported Pearson correlation r=0.72 between caregiver burden and caregiver depressive symptoms in this sample); 0.4-0.9 range is an assumed exploration bound, not from the source.

OUTPUTS (5)
-----------
- Annualized caregiving hours: 5,168.8 (hours/year) at default assumptions
- Caregiving hours above a standard full-time workweek (positive = exceeds benchmark; negative = below it): 59.4 (hours/week) at default assumptions
- Depressive symptom score linked to a given burden level (Geriatric Depression Scale, 0-15): 4.3 (score (0-15 scale)) at default assumptions
- Caregiver burden score as percent of maximum scale score: 32.92 (percent) at default assumptions
- Concurrent BPSD symptom count as percent of maximum scale score: 40.83 (percent) at default assumptions

FILES IN THIS BUNDLE
---------------------
This is the trimmed public-demo copy of the bundle. These parts are not included here: provenance-and-review.json (the complete model-call audit trail); input/ (the uploaded source paper); federal_sources/ (the raw federal data files); source/ (the application source code). The uploaded paper is left out because it may be copyrighted (the Original Source section links to it), and the raw federal files are left out for size (the processed summaries the model saw are included under input/federal_knowledge/). The complete bundle, with every part, is produced by the full tool run on your own machine.

Spec.json                    - interactive simulator specification (JSON AST)
fhir_demonstration.json      - the inputs and default outputs as a FHIR R4-shaped demonstration bundle
                               with provenance (not clinical data, not certified; see the app FAQ)
fhir_definitions.json        - definitions of the DBbun extensions and code systems used by that file
Documentation.pdf            - this documentation, formatted
Scientific_Analysis.json     - full extracted analysis behind the spec
README.txt                   - this file
NOTICE.txt                   - what this bundle is and is not
input/federal_knowledge/     - the processed federal-knowledge summaries an
                               excerpt of each was drawn from
evidence_cards/              - the computed federal evidence cards (with their data
                               tables) the federal cross-checks used, if any
sim_outputs/                - scenario_sweeps.csv, one scenario-sweep PNG chart
                               and one sensitivity ("_sensitivity.png") chart per
                               output; monte_carlo_sample.csv, 500 randomized
                               full-input draws (see NOTICE.txt for what this is
                               and is not); monte_carlo_summary.csv, mean/std/min/
                               max per output across that sample; plus the
                               downloadable Python source if that generation step
                               completed

DECISION BOUNDARY
-----------------
This is a deterministic arithmetic simulator over a compact, human-reviewed
specification extracted from one document, not an agent-based model or a
substitute for the source publication. monte_carlo_sample.csv uses real random
sampling (uniform draws within each input's own declared exploration range),
but that range itself is an assumption, not a fitted probability distribution -
see Documentation.pdf for the full parameter provenance and stated limitations.