mean_weekly_caregiving_hours = 99.4
full_time_workweek_hours = 40
caregiver_burden_score = 7.9
bpsd_symptom_count = 4.9
correlation_r = 0.72


def compute_annual_caregiving_hours(mean_weekly_caregiving_hours):
    return mean_weekly_caregiving_hours * 52


def compute_weekly_hours_above_fulltime_benchmark(mean_weekly_caregiving_hours,
                                                    full_time_workweek_hours):
    return mean_weekly_caregiving_hours - full_time_workweek_hours


def compute_predicted_depression_score_from_burden(correlation_r,
                                                     caregiver_burden_score):
    slope = correlation_r * (2.8 / 6.3)
    intercept = 4.3 - slope * 7.9
    return intercept + slope * caregiver_burden_score


def compute_burden_severity_percent_of_scale(caregiver_burden_score):
    return (caregiver_burden_score / 24) * 100


def compute_bpsd_symptom_share_of_scale(bpsd_symptom_count):
    return (bpsd_symptom_count / 12) * 100


def compute_cumulative_caregiving_hours_trajectory(annual_caregiving_hours,
                                                     periods=5):
    trajectory = []
    prev = 0
    for _ in range(periods):
        prev = prev + annual_caregiving_hours
        trajectory.append(prev)
    return trajectory


if __name__ == "__main__":
    annual_caregiving_hours = compute_annual_caregiving_hours(
        mean_weekly_caregiving_hours
    )
    weekly_hours_above_fulltime_benchmark = (
        compute_weekly_hours_above_fulltime_benchmark(
            mean_weekly_caregiving_hours, full_time_workweek_hours
        )
    )
    predicted_depression_score_from_burden = (
        compute_predicted_depression_score_from_burden(
            correlation_r, caregiver_burden_score
        )
    )
    burden_severity_percent_of_scale = (
        compute_burden_severity_percent_of_scale(caregiver_burden_score)
    )
    bpsd_symptom_share_of_scale = compute_bpsd_symptom_share_of_scale(
        bpsd_symptom_count
    )
    cumulative_caregiving_hours = (
        compute_cumulative_caregiving_hours_trajectory(
            annual_caregiving_hours, periods=5
        )
    )

    print("Inputs (defaults):")
    print(f"  mean_weekly_caregiving_hours = {mean_weekly_caregiving_hours}")
    print(f"  full_time_workweek_hours = {full_time_workweek_hours}")
    print(f"  caregiver_burden_score = {caregiver_burden_score}")
    print(f"  bpsd_symptom_count = {bpsd_symptom_count}")
    print(f"  correlation_r = {correlation_r}")
    print()
    print("Outputs:")
    print(
        f"  annual_caregiving_hours = {annual_caregiving_hours} hours/year"
    )
    print(
        "  weekly_hours_above_fulltime_benchmark = "
        f"{weekly_hours_above_fulltime_benchmark} hours/week"
    )
    print(
        "  predicted_depression_score_from_burden = "
        f"{predicted_depression_score_from_burden} (0-15 scale)"
    )
    print(
        "  burden_severity_percent_of_scale = "
        f"{burden_severity_percent_of_scale} percent"
    )
    print(
        "  bpsd_symptom_share_of_scale = "
        f"{bpsd_symptom_share_of_scale} percent"
    )
    print()
    print(
        "Trajectory - cumulative_caregiving_hours "
        "(flat annual repetition, 5 years):"
    )
    for year_index, value in enumerate(cumulative_caregiving_hours, start=1):
        print(f"  year {year_index}: {value} hours/caregiver")